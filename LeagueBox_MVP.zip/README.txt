LEAGUE BOX MVP
Open index.html in a browser. Data is stored locally in the browser.
Features:
- Create leagues
- Add/remove teams
- Enter and edit scores
- Automatic W/L, PF, PA and point differential standings
- Create tournaments
- Generate brackets
- Edit bracket matchups
- Enter scores and advance winners
- Data persists in localStorage

For an iPhone Home Screen app, the files need to be hosted at an HTTPS URL. Then open the URL in Safari and choose Share -> Add to Home Screen.
